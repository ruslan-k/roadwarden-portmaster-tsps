# Roadwarden Ren'Py 8.3.4 GPU probe (TSPS)

This is a controlled experiment, not a verified GPU-capable build. It modifies
only the port's launcher and game overlay. It does not replace the stock
PortMaster `renpy_8.3.4.squashfs` or any system library.

## Installation

Back up `Roadwarden.sh` and `game/zz_tsps_port.rpy` from the existing port.
Copy these two replacement files into the corresponding paths of the port.
Start the game from PortMaster normally.

## Why this might work

The current startup log includes `Initializing gl2 renderer: GL Disabled.`.
In stock Ren'Py 8.3.4, this comes from `GL2Draw.init()` when
`renpy.config.gl_enable` is false. That implies the `gl2draw` module was
imported successfully, despite the absent legacy `gldraw` module.

The game overlay now sets `config.gl_enable = True` during early init.
The launcher chooses `RENPY_RENDERER=gles2` by default. If GLES2 context
creation fails, Ren'Py should normally try its software fallback.

## Inspect actual renderer

    grep -Ei 'requested renderer|Initializing .*renderer|GL Disabled|Unknown renderer|Vendor:|Renderer:|Version:|Could not get pygame screen|Using .*renderer|SDL|EGL|GLX|traceback' /path/to/roadwarden/log.txt

Success requires `Initializing gles2 renderer` followed by a real Mali GPU
vendor/renderer and no fallback to `Initializing sw renderer`.

An import error for `renpy.gl.gldraw` alone does not rule out `gles2`:
that newer backend imports `renpy.gl2.gl2draw`.

## Rollback / comparison

Add this before the line `export RENPY_RENDERER=` in the launcher:

    RENPY_RENDERER=sw

The test launcher will then select the software renderer. To fully revert,
restore the backed-up port files.

## When GLES context creation fails

1. Inspect the log. If `GL Disabled.` is still emitted, the game overlay did
   not take effect early enough; try a port-local bind mount of a patched
   `renpy/config.py` with `gl_enable = True` (as in nitou2504's runtime notes).
2. If `Could not get pygame screen` or `EGL_BAD_MATCH`, the missing piece is
   an EGL-capable SDL video driver / Mali library stack, not a renderer module.
3. Examine the currently sourced `libgl_$CFW_NAME.txt` and its `libGL.so`
   setup. `gles2` needs real EGL/GLES; an X11 GL4ES route may require
   `RENPY_RENDERER=gl2` and Westonpack instead.
4. Avoid mixing Debian's `python3-renpy` extension binaries with the
   PortMaster Python runtime: Python/glibc ABIs differ.

Refs:
- https://github.com/renpy/renpy/blob/8.3.4.24120703/renpy/gl2/gl2draw.pyx
- https://github.com/nitou2504/renpy-portmaster-runtime/blob/main/RUNTIME.md
- https://www.renpy.org/release/8.3.4
