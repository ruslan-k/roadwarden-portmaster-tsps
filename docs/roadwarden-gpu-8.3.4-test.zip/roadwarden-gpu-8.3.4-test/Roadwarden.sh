#!/bin/bash
# PORTMASTER: roadwarden.zip, Roadwarden.sh

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

# SpruceOS keeps the active PortMaster under Persistent/portmaster while the
# legacy Apps/PortMaster directory only contains compatibility assets.
# Fall back to the complete installation when the path from control.txt is
# incomplete, without changing the system-wide PortMaster configuration.
if [ ! -f "$controlfolder/funcs.txt" ] && [ -f "/mnt/SDCARD/Persistent/portmaster/PortMaster/funcs.txt" ]; then
  controlfolder="/mnt/SDCARD/Persistent/portmaster/PortMaster"
  export controlfolder
  source "$controlfolder/device_info.txt"
  source "$controlfolder/funcs.txt"
  export SDL_GAMECONTROLLERCONFIG_FILE="/$controlfolder/gamecontrollerdb.txt"
  export GPTOKEYB2="$ESUDO env LD_PRELOAD=$controlfolder/libinterpose.aarch64.so $controlfolder/gptokeyb2 $ESUDOKILL"
  export GPTOKEYB="$ESUDO $controlfolder/gptokeyb $ESUDOKILL"
fi

[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

# Variables
PORTEXEC="renpy/startRENPY"
if [ -d "/mnt/SDCARD/Roms/PORTS/roadwarden" ]; then
  GAMEDIR="/mnt/SDCARD/Roms/PORTS/roadwarden"
else
  GAMEDIR="/$directory/ports/roadwarden"
fi

cd $GAMEDIR

runtime="renpy_8.3.4"
if [ ! -f "$controlfolder/libs/${runtime}.squashfs" ]; then
  # Check for runtime if not downloaded via PM
  if [ ! -f "$controlfolder/harbourmaster" ]; then
    pm_message "This port requires the latest PortMaster to run, please go to https://portmaster.games/ for more info."
    sleep 5
    exit 1
  fi

  $ESUDO $controlfolder/harbourmaster --quiet --no-check runtime_check "${runtime}.squashfs"
fi

# Savedata setup
mkdir -p $GAMEDIR/conf
export XDG_DATA_HOME="$GAMEDIR/conf"
bind_directories ~/.renpy/ $GAMEDIR/conf/

renpydir="$GAMEDIR/renpy"
gamefiles="$GAMEDIR/game"
renpy_runtime="$controlfolder/libs/${runtime}.squashfs"
$ESUDO mkdir -p "$renpydir"

# Mounting Renpy and gamefiles
$ESUDO umount "$renpydir/game" || true
$ESUDO umount "$renpy_runtime" || true
$ESUDO mount "$renpy_runtime" "$renpydir"
sleep 2
$ESUDO mount --bind "$gamefiles" "$renpydir/game"

# Exports
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
export LD_LIBRARY_PATH="$GAMEDIR/libs:$LD_LIBRARY_PATH"
export PYTHONHOME=$GAMEDIR/renpy/
export SDL_AUDIODRIVER=alsa
export AUDIODEV=hw:0,0
export RENPY_LOG_BASE="$GAMEDIR/conf"
export PYTHONPATH=$GAMEDIR/renpy/lib/python3.9

# If using gl4es
if [ -f "${controlfolder}/libgl_${CFW_NAME}.txt" ]; then
  source "${controlfolder}/libgl_${CFW_NAME}.txt"
else
  source "${controlfolder}/libgl_default.txt"
fi

# NEW: Prefer the built-in Ren'Py GL2 GLES backend. Roll back with
# RENPY_RENDERER=sw. This does not install or overwrite a system runtime.
export RENPY_RENDERER="${RENPY_RENDERER:-gles2}"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1
echo "Roadwarden requested renderer: $RENPY_RENDERER"

pm_platform_helper "$GAMEDIR/renpy/lib/py3-linux-aarch64/startRENPY"
$GPTOKEYB "startRENPY" -c "roadwarden.gptk"  &

"./$PORTEXEC"

pm_finish

if [[ "$PM_CAN_MOUNT" != "N" ]]; then
    $ESUDO umount "$renpydir/game"
    $ESUDO umount "$renpydir"
fi
